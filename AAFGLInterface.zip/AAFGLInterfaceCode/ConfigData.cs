﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

using System.Configuration;
using System.Diagnostics;

namespace AAFGLInterface
{
    public class ConfigData
    {
        //----------------------
        #region DB
        SqlConnection sqlconn = new SqlConnection();
        CLS_CONN conn = new CLS_CONN();
        #endregion DB
        //----------------------

        public static string get_sourcefilename()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'sourcefilename'";
        }
        public static string get_userFile()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'userFile'";
        }
        public static string get_forManualUpload()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData]where config_name = 'forManualUpload'";
        }
        public static string get_outputfilename()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'outputfilename'";
        }
        public static string get_logFileFolder()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'logFileFolder'";
        }
        public static string get_fileToICBS()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'fileToICBS'";
        }
        public static string get_ppkpath()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'ppkpath'";
        }
        public static string get_convertto()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'convertto'";
        }
        public static string get_codepage()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'codepage'";
        }
        public static string get_crlf()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'crlf'";
        }
        public static string get_skipbytesforcrlf()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'skipbytesforcrlf'";
        }
        public static string get_sourcefilenametoSFTP()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'sourcefilenametoSFTP'";
        }
        public static string get_hostname()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'hostname'";
        }

        public static string get_username()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'username'";
        }

        public static string get_password()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'password'";
        }
        public static string get_portnumber()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'portnumber'";
        }
        public static string get_ftpICBSFilePath()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'ftpICBSFilePath'";
        }
        public static string get_ftpSSHFingerPrint()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'ftpSSHFingerPrint'";
        }
        public static string get_scheduledTimeForUpload()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'scheduledTimeForUpload'";
        }
        public static string get_scheduledTimeToCollectFiles()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'scheduledTimeToCollectFiles'";
        }

        public static string get_includeBDOLFS()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'includeBDOLFS'";
        }

        public static string get_includeBDORIS()
        {
            return "select config_value from [BDOLFTB_GLInterfaceConfigData] where config_name = 'includeBDORIS'";
        }


        //----------------------
        public static string get_glInterfaceConfigData(string connectionString, string query)
        {
            string result = string.Empty;
            try {
               // string result = string.Empty;
                SqlConnection sqlconn = new SqlConnection();
                sqlconn = new SqlConnection(connectionString.Trim());
                sqlconn.Open();
                SqlCommand sqlcm = new SqlCommand(query, sqlconn);
                sqlcm.Prepare();
                SqlDataReader rdr = sqlcm.ExecuteReader();
                if (rdr.Read())
                {
                    if (rdr["config_value"].ToString() != null)
                    {
                        result = rdr["config_value"].ToString();
                    }
                    else
                    {
                        result = string.Empty;   //setting to 0 if not holiday
                    }
                }
                sqlconn.Close();
                
            }
            catch (Exception eee) {
                EventLog.WriteEntry("AAFGLInterface", connectionString+"\nStack Trace:  "+ eee.StackTrace+"\nMessage: ConfigData Module: "+eee.Message , EventLogEntryType.Error);
            }
            return result;
        }

        //-------------------------------------



    }
}
