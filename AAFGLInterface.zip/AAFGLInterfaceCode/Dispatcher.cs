﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Configuration;
using System.Diagnostics;

namespace AAFGLInterface
{
    class Dispatcher
    {
        static DateTime dateNow;
        public static string _tmpfile = "";
        static string connString = CLS_CONN.connString();
        //---------------------------------------
        static string _userFile = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_userFile());
        static string _forManualUpload = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_forManualUpload());
        static string _sourceFilePath = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_sourcefilename());
        static string _scheduledTimeForUpload = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_scheduledTimeForUpload());
        static string _outputFileName = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_outputfilename());
        //-----------------------------------------------------------
        public static void mainProcess(string timeToSendToServer, DateTime dateOfServer)
        {
            string timeToSend = _scheduledTimeForUpload; //@"2:00 AM";
            dateNow = dateOfServer;
            //if (timeToSend == GetHourTimeToSend("Data Source = DESKTOP-THFQAN9; Initial Catalog = dbAAF; Persist Security Info = false; Integrated Security = SSPI"))
            if(timeToSend == _scheduledTimeForUpload) //GetHourTimeToSend(connString))
            {
                //----------------
                //check if yesterday is holiday
                string holidayDate = GetHolidayThisMonth(dateNow.AddDays(-1), connString);
                //========================
                if(holidayDate != string.Empty)
                { // if yesterday is holiday
                    //------------------------------------------
                    if(getLastDayPreviousMonth(dateNow).Subtract(dateNow).Days == -1)
                    {
                        // Continue to process.
                    }
                    else
                    {
                        return; //stop processing 
                    }

                    // ("Holiday yesterda- Do not send anything ");
                    if(dateNow.DayOfWeek == DayOfWeek.Monday && dateNow.Day <= 7)
                    {
                        DateTime lastDayPrevMonth = getLastDayPreviousMonth(dateNow);
                        //------------------
                        if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday" || lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                        {
                            //("Saturday/Sunday falls in last day prev month");
                            //("First Monday of the month");

                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday")
                            {
                                //Monday @2AM
                                //("Transfer SATURDAY record to ForManulaUpload folder for manual upload.");
                            }
                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                            {
                                //Monday @2AM
                                //("Is SUNDAY is month-end, merge generated GL interface file of SATURDAY and SUNDAY then transfer on MONDAY the GL interface file to ICBS shared folder");
                                //("Accounting will manually upload the merged GL interface file of SATURDAY and SUNDAY on MONDAY");
                                ManualUpload(_sourceFilePath + @"\", _forManualUpload + @"\", "*.fmu");
                                return;
                            }
                        }
                    }
                    //----------------------------------------------
                }
                else
                {
                    //Send File from previous day
                    //  M  O  N  D  A  Y
                    //------------------------------------------------------------------------
                    //getting if FIRST MONDAY of the first week of the month
                    if(dateNow.DayOfWeek == DayOfWeek.Monday && dateNow.Day <= 7)
                    {
                        DateTime lastDayPrevMonth = getLastDayPreviousMonth(dateNow);
                        //------------------
                        if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday" || lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                        {
                            //("Saturday/Sunday falls in last day prev month");
                            //("First Monday of the month");

                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday")
                            {
                                //Monday @2AM
                                //("Transfer SATURDAY record to ForManulaUpload folder for manual upload.");
                            }
                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                            {
                                //Monday @2AM
                                //("Is SUNDAY is month-end, merge generated GL interface file of SATURDAY and SUNDAY then transfer on MONDAY the GL interface file to ICBS shared folder");
                                //("Accounting will manually upload the merged GL interface file of SATURDAY and SUNDAY on MONDAY");
                                ManualUpload(_sourceFilePath + @"\", _forManualUpload + @"\", "*.fmu");
                                return;
                            }
                        }
                        else
                        {
                            //("Regular Monday - Saturday or Sunday is not the month-end");
                            return;
                        }
                        //------------------
                    }
                    else
                    {
                        //Regular Monday - 2nd to 4 th week
                        if(dateNow.DayOfWeek == DayOfWeek.Monday)
                        {
                            //("Regular Monday - 2nd to 4 th week");
                            //("Regular Monday - Saturday or Sunday is not the month-end");
                            return;
                        }
                    }
                    //------------------
                    //  T  U  E  S  D  A  Y
                    //------------------------------------------------------------------------
                    if(dateNow.DayOfWeek == DayOfWeek.Tuesday && dateNow.Day <= 7)
                    {
                        //("First Tuesday");
                        DateTime lastDayPrevMonth = getLastDayPreviousMonth(dateNow);
                        //------------------
                        if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday" || lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                        {
                            //("Saturday/Sunday falls in last day prev month");
                            //("First Tuesday of the month");
                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday")
                            {
                                //("If SATURDAY is month-end, merge generated GL interface file of SUNDAY and MONDAY then transfer to ICBSshared folder for GL upload.");
                                //("Accounting will manually upload the GL interface file of SATURDAY and SUNDAY.");
                                RegularUpload();
                            }
                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                            {
                                // ("If SUNDAY is month-end, merge generated GL interface file of SATURDAY and SUNDAY then transfer to ICBSshared folder for GL upload.");
                                //("Accounting will manually upload the merged GL interface file of SATURDAY and SUNDAY on MONDAY.");
                                RegularUpload();
                            }
                        }
                        else
                        {
                            //Regular Tuesday - from 2nd week to last week of the month
                            //("Regular Tuesday - If Saturday or Sunday is not the day of the previous month");
                            //("If Saturday and Sunday is not month-end-merge generated GL interface file os SATURDAY, SUNDAY, and MONDAY then transfer to ICBS shared folder");
                            RegularUpload();
                            return;
                        }
                        //------------------
                    }
                    else
                    {
                        //Regular Tuesday - 2nd to 4 th week
                        if(dateNow.DayOfWeek == DayOfWeek.Tuesday)
                        {
                            //("Regular Tuesday - 2nd to 4 th week");
                            //("If Saturday and Sunday is not month-end-merge generated GL interface file os SATURDAY, SUNDAY, and MONDAY then transfer to ICBS shared folder");
                            RegularUpload();
                        }
                    }
                    //------------------------------------------------------------------------
                    //  W  E  D  N  E  S  D  A  Y
                    if(dateNow.DayOfWeek.ToString() == "Wednesday")
                    {
                        //("Wednesday-Send Tuesday");
                        RegularUpload();
                    }
                    //  T  H  U  R  S  D  A  Y
                    if(dateNow.DayOfWeek.ToString() == "Thursday")
                    {
                        //("Thursday-Send Wedenesday");
                        RegularUpload();
                    }
                    //  F  R  I  D  A  Y
                    if(dateNow.DayOfWeek.ToString() == "Friday")
                    {
                        //("Friday - Send Thursday");
                        RegularUpload();
                    }
                    //  S  A  T  U  R  D  A  Y
                    if(dateNow.DayOfWeek.ToString() == "Saturday")
                    {
                        //("Saturday - Send Friday");
                        RegularUpload();
                    }
                    //  S  U  N  D  A  Y
                    //------------------------------------------------------------------------
                    if(dateNow.DayOfWeek == DayOfWeek.Sunday && dateNow.Day <= 7)
                    {
                        DateTime lastDayPrevMonth = getLastDayPreviousMonth(dateNow);
                        //------------------
                        if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday" || lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                        {
                            //("Saturday/Sunday falls in last day prev month");
                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Saturday")
                            {
                                //Monday @2AM
                                ManualUpload(_sourceFilePath + @"\", _forManualUpload + @"\", "*.fmu");
                                return;
                            }
                            if(lastDayPrevMonth.DayOfWeek.ToString() == "Sunday")
                            {
                                //("If SUNDAY is month-end, merge generated GL interface file of SATURDAY and SUNDAY then transfer to ICBSshared folder for GL upload.");
                                //("Accounting will manually upload the merged GL interface file of SATURDAY and SUNDAY on MONDAY.");
                            }
                        }
                        else
                        {
                            //Regular Tuesday - from 2nd week to last week of the month
                            //("Regular Tuesday - If Saturday or Sunday is not the day of the previous month");
                            //("If Saturday and Sunday is not month-end-merge generated GL interface file os SATURDAY, SUNDAY, and MONDAY then transfer to ICBS shared folder");
                            return;
                        }
                        //------------------
                    }
                    else
                    {
                        //Regular Tuesday - 2nd to 4 th week
                        if(dateNow.DayOfWeek == DayOfWeek.Sunday)
                        {
                            //("Regular Tuesday - 2nd to 4 th week");
                            //("If Saturday and Sunday is not month-end-merge generated GL interface file os SATURDAY, SUNDAY, and MONDAY then transfer to ICBS shared folder");
                            return;
                        }
                    }
                    //------------------------------------------------------------------------
                }
                //-----------------
            }
            else
            {//end of 2:00 AM
             //("Idle for Sending file");
            }
            //------------------

            #region Days Validation
            //JulianDateValidatorForMonthEnd();
            #endregion
        }

        private static void JulianDateValidatorForMonthEnd()
        {
            switch(dateNow.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    //Initializer
                    JulianDateConverter jdc = new JulianDateConverter(_sourceFilePath);

                    //Get LastDay of the Month
                    var lastdayofthemonth = DateTime.DaysInMonth(dateNow.Year, dateNow.Month);

                    //Get Date of yesterday
                    var yesterdayDate = dateNow.AddDays(-1);

                    //Get Next Working Day
                    var NextWorkingday = jdc.GetNextWorkingDays(dateNow);

                    var dLastDayOfLastMonth = dateNow.AddDays(-2);


                    if(dateNow.Day == 2)
                    {
                        // string[] filesToTransfer = Directory.GetFiles(_sourceFilePath, @"*.txt");
                        //Based from SATURDAY,SUNDAY and HOLIDAYS scenarios
                        // Process.MergeFiles(_sourceFilePath + @"\");

                        yesterdayDate = yesterdayDate.AddDays(-1);

                        if(yesterdayDate.Day == dLastDayOfLastMonth.Day)
                        {
                            jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(dateNow.AddDays(-1)));
                        }
                    }
                    else if(dateNow.Day == lastdayofthemonth) //Check if last day of the month is sunday
                    {
                        //Effectivity date should be on next workng days
                        jdc.ReplaceValue(jdc.NextJDC_BusinessDay(NextWorkingday));
                    }
                    else
                    {
                        jdc.ReplaceValue(jdc.PrevJDC_BusinessDay(NextWorkingday));
                    }
                    break;

            }
        }

        //-------------------
        //METHODS

        public static void ManualUpload(string sourcePath, string destinationPath, string extFileName)
        {
            if(dateNow.AddDays(-1).DayOfWeek == DayOfWeek.Sunday)
            {
                var lastdayofthemonth = new DateTime(dateNow.Year, dateNow.Month, 1).AddDays(-1);
                if(dateNow.AddDays(-1).Day == lastdayofthemonth.Day)
                { 
                    return;
                } 
            }

            //BackUp *.txt Files to AAF_FILES
            Process.SendFilesToFolder(_sourceFilePath + @"\", _userFile + @"\", @"*.txt");

            //Based from SATURDAY,SUNDAY and HOLIDAYS scenarios
            Process.MergeFiles(sourcePath);

            JulianDateValidator(sourcePath, destinationPath, extFileName);

            //BackUp @"GLT9093AAF.filepart" Files to AAF_Files and rename to "MMddyyyymmss" format
            //Process.RenameAndSendFilesToFolder(_sourceFilePath + @"\", _userFile + @"\", @"GLT9093AAF.filepart");

            //Send final file to Folder for SFTP Upload
            Process.SendFilesToFolder(sourcePath, destinationPath, extFileName);

            //BackUp *.xml Files to AAF_FILES
            Process.SendFilesToFolder(_sourceFilePath + @"\", _userFile + @"\", @"*.xml");

            //Clean up Directory
            Process.cleaningDirectory(sourcePath);
        }

        private static void JulianDateValidator(string sourcePath, string destinationPath, string extFileName)
        {
            //Get Holiday using current date
            var Holidate = Dispatcher.GetHolidayThisMonth(dateNow, connString);

            var renamedfile = sourcePath + _tmpfile;

            File.Move(renamedfile, Path.ChangeExtension(renamedfile, ".fmu"));
            var newname = Path.GetFileNameWithoutExtension(renamedfile);


            JulianDate_fmu JDF = new JulianDate_fmu();
            JDF.Main(sourcePath + newname + ".fmu", sourcePath, destinationPath, extFileName, true);

            //var fileName = Convert.ToString(DateTime.Now.ToString("MMddyyyymmss")) + "Manual.fin.txt";

            //File.Copy(sourcePath + newname + ".fmu", sourcePath + fileName);
            //File.Move(sourcePath + newname + ".fmu", _userFile + @"\" + fileName);
        }


        public static void RegularUpload()
        {
            //BackUp *.txt Files to AAF_FILES
            Process.SendFilesToFolder(_sourceFilePath + @"\", _userFile + @"\", @"*.txt");

            //Based from SATURDAY,SUNDAY and HOLIDAYS scenarios
            Process.ProcessFiles(_sourceFilePath + @"\");

            //Send final file to Folder for SFTP Upload
            Process.SendFilesToFolder(_sourceFilePath + @"\", _outputFileName + @"\", @"*.MBR");

            //BackUp @"GLT9093AAF.filepart" Files to AAF_Files and rename to "MMddyyyymmss" format
            Process.RenameAndSendFilesToFolder(_sourceFilePath + @"\", _userFile + @"\", @"GLT9093AAF.filepart");

            //BackUp *.xml Files to AAF_FILES
            Process.SendFilesToFolder(_sourceFilePath + @"\", _userFile + @"\", @"*.xml");

            //Clean up Directory
            Process.cleaningDirectory(_sourceFilePath + @"\");
        }

        public static string GetHolidayThisMonth(DateTime today, string connectionString)
        {
            string result = string.Empty;
            SqlConnection sqlconn = new SqlConnection();
            sqlconn = new SqlConnection(connectionString.Trim());
            sqlconn.Open();
            string _CurrentDate = String.Format("{0:d}", today).Trim();
            SqlCommand sqlcm = new SqlCommand("select holiday_dt from holiday where holiday_dt = @dt", sqlconn);
            sqlcm.Prepare();
            sqlcm.Parameters.Add("@dt", SqlDbType.NVarChar, 30);
            sqlcm.Parameters["@dt"].Value = _CurrentDate;
            SqlDataReader rdr = sqlcm.ExecuteReader();
            if(rdr.Read())
            {
                if(rdr["holiday_dt"].ToString() != null)
                {
                    result = rdr["holiday_dt"].ToString();
                }
                else
                {
                    result = string.Empty;   //setting to 0 if not holiday
                }
            }
            sqlconn.Close();
            return result;
        }
        //-------------------
        public static DateTime getLastDayPreviousMonth(DateTime dt)
        {
            DateTime startOfMonth = new DateTime(dt.Year, dt.Month, 1);
            DateTime endOfPreviousmonth = startOfMonth.AddDays(-1);
            return endOfPreviousmonth;
        }
        //-----------------------
        public static string GetServerDate(string connectionString)
        {
            string result = string.Empty;
            SqlConnection sqlconn = new SqlConnection();
            sqlconn = new SqlConnection(connectionString.Trim());
            sqlconn.Open();
            SqlCommand sqlcm = new SqlCommand(" select server_dt from dbo.axvw_get_datetime", sqlconn);
            sqlcm.Prepare();
            SqlDataReader rdr = sqlcm.ExecuteReader();
            if(rdr.Read())
            {
                if(rdr["server_dt"].ToString() != null)
                {
                    result = rdr["server_dt"].ToString();
                }
                else
                {
                    result = string.Empty;   //setting to 0 if not holiday
                }
            }
            sqlconn.Close();
            return result;
        }

        ////------------------------------------
        public static string get_glInterfaceUploadTime(string connectionString)
        {
            string result = string.Empty;
            SqlConnection sqlconn = new SqlConnection();
            sqlconn = new SqlConnection(connectionString.Trim());
            sqlconn.Open();
            SqlCommand sqlcm = new SqlCommand("select config_value from BDOLFTB_GLInterfaceConfigData where config_name = 'scheduledTimeForUpload' ", sqlconn);
            sqlcm.Prepare();
            SqlDataReader rdr = sqlcm.ExecuteReader();
            if(rdr.Read())
            {
                if(rdr["config_value"].ToString() != null)
                {
                    result = rdr["config_value"].ToString();
                }
                else
                {
                    result = string.Empty;   //setting to 0 if not holiday
                }
            }
            sqlconn.Close();
            return result;
        }

        //-------------------------------------
    }
    //-----------------------------------------------------------

}
