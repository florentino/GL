﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AAFGLInterface
{
    public class PrevAndNxtWorkingDays
    {
        private static DateTime Holidays = new DateTime();
        //static DateTime presult;
        //static DateTime nresult;

        public void HolidayValidator(DateTime holidate, DateTime today, out DateTime _presult, out DateTime _nresult)
        {  
            Holidays = holidate;
            var date = today;
            DateTime presult = Holidays;
            DateTime nresult = Holidays;

            switch(date.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
                case DayOfWeek.Monday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
                case DayOfWeek.Tuesday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
                case DayOfWeek.Wednesday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
                case DayOfWeek.Thursday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
                case DayOfWeek.Friday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
                case DayOfWeek.Saturday:
                    nresult = NextBusinessDay(holidate, date);
                    presult = PreviousBusinessDay(holidate, date);
                    break;
            }

            _nresult = nresult;
            _presult = presult;

        }

        public DateTime PreviousBusinessDay(DateTime? holidate, DateTime prevworkingday)
        {
            if(!holidate.HasValue)   // not equal to null
            {
                if(holidate == prevworkingday)
                {    
                    PreviousBusinessDay(holidate, prevworkingday.AddDays(-1));
                }
            }
            else
            {
                switch(prevworkingday.DayOfWeek)
                {
                    case DayOfWeek.Sunday:
                        break;
                    case DayOfWeek.Monday:
                        break;
                    case DayOfWeek.Tuesday:
                        break;
                    case DayOfWeek.Wednesday:
                        break;
                    case DayOfWeek.Thursday:
                        break;
                    case DayOfWeek.Friday:
                        break;
                    case DayOfWeek.Saturday:
                        prevworkingday = PreviousBusinessDay(holidate, prevworkingday.AddDays(-1));
                        break;
                }
            }
            return prevworkingday;
        }

        public DateTime NextBusinessDay(DateTime? holidate, DateTime today)
        {
            if(!holidate.HasValue)   // not equal to null
            {
                if(holidate == today)
                {
                    NextBusinessDay(holidate, today.AddDays(1));
                }
            } 
            else
            {
                switch(today.DayOfWeek)
                {
                    case DayOfWeek.Sunday:
                        today = NextBusinessDay(holidate, today.AddDays(1));
                        break;
                    case DayOfWeek.Monday:
                        break;
                    case DayOfWeek.Tuesday:
                        break;
                    case DayOfWeek.Wednesday:
                        break;
                    case DayOfWeek.Thursday:
                        break;
                    case DayOfWeek.Friday:
                        break;
                    case DayOfWeek.Saturday:
                        today = NextBusinessDay(holidate, today.AddDays(1));
                        break;
                }
            }
            return today;
        }

        public bool TomorrowIsSaturday(DateTime tomorrow)
        {
            tomorrow = tomorrow.AddDays(1);
            bool itsAHoliday = false;

           
            
            switch(tomorrow.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    break;
                case DayOfWeek.Monday:
                    break;
                case DayOfWeek.Tuesday:
                    break;
                case DayOfWeek.Wednesday:
                    break;
                case DayOfWeek.Thursday:
                    break;
                case DayOfWeek.Friday:
                    break;
                case DayOfWeek.Saturday:
                    itsAHoliday = true;
                    break;
            }
           
            return itsAHoliday;
        }

        public bool YesterdayIsSunday(DateTime yesterday)
        {
            yesterday = yesterday.AddDays(-1);
            bool itsAHoliday = false;

            switch(yesterday.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    itsAHoliday = true;
                    break;
                case DayOfWeek.Monday:
                    break;
                case DayOfWeek.Tuesday:
                    break;
                case DayOfWeek.Wednesday:
                    break;
                case DayOfWeek.Thursday:
                    break;
                case DayOfWeek.Friday:
                    break;
                case DayOfWeek.Saturday:
                    break;
            }
            
            return itsAHoliday;
        }

        public bool FastpresentFuture(DateTime date)
        {
            date = date.AddDays(-1);
            bool itsAHoliday = false;

            switch(date.DayOfWeek)
            {
                case DayOfWeek.Sunday:
                    itsAHoliday = true;
                    break;
                case DayOfWeek.Monday:
                    break;
                case DayOfWeek.Tuesday:
                    break;
                case DayOfWeek.Wednesday:
                    break;
                case DayOfWeek.Thursday:
                    break;
                case DayOfWeek.Friday:
                    break;
                case DayOfWeek.Saturday:
                    break;
            }

            return itsAHoliday;
        }
    }
}
