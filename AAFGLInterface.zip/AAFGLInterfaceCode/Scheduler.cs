﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Diagnostics;
using System.IO;
//jgt: Windows Service Scheduling to run once a day in specific time
namespace AAFGLInterface
{
    class Scheduler
    {
        static System.Timers.Timer _timer;
           static string connString = CLS_CONN.connString();
        //---------------------------------------
      //static string _scheduledRunningTime = ConfigurationManager.AppSettings["scheduledTimeForUpload"]; //"6:00 AM";
        static string _scheduledRunningTime = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_scheduledTimeForUpload());
            //static string _collectFiles = ConfigurationManager.AppSettings["scheduledTimeToCollectFiles"]; //"11:00 AM";
        static string _collectFiles = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_scheduledTimeToCollectFiles());
            // static string _sourcefilename = ConfigurationManager.AppSettings["sourcefilename"];
        static string _sourcefilename = ConfigData.get_glInterfaceConfigData(connString,ConfigData.get_sourcefilename());
            //static string _forManualUpload = ConfigurationManager.AppSettings["forManualUpload"];
        static string _forManualUpload = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_forManualUpload());
            //static string _outputfilename = ConfigurationManager.AppSettings["outputfilename"];
        static string _outputfilename = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_outputfilename());
            //static string _fileToICBS = ConfigurationManager.AppSettings["fileToICBS"];
        static string _fileToICBS = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_fileToICBS());
            //static string _codepage = ConfigurationManager.AppSettings["codepage"];
        static string _codepage = ConfigData.get_glInterfaceConfigData(connString, ConfigData.get_codepage());


        //System.Timers.Timer oTimer = null;
        //double interval = 20000;
        public void Start() {
            try
            {
                _timer = new System.Timers.Timer();
                _timer.Interval = 1 * 60 * 1000; //Every one minute
                _timer.AutoReset = true;
                _timer.Enabled = true;
                _timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
                _timer.Start();
            }
            catch (Exception ex) {
                 EventLog.WriteEntry("AAFGLInterface", "\nStack Trace:  " + ex.StackTrace + "\nMessage: Scheduler Module:  " + ex.Message, EventLogEntryType.Error);
            }
        }
        // private void oTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        private void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            //Portion to send the file to ICBS
            string _CurrentTime = String.Format("{0:t}", DateTime.Now).Trim();
            // Call function to detect If Saturdays/Sundays/Regular Holidays /Non working Days - do not send the files to ICBS
        string glUploadTime = Dispatcher.get_glInterfaceUploadTime(connString);
             //---------------------------------------
            if (glUploadTime.ToString() != string.Empty)
            {
                _scheduledRunningTime = glUploadTime.Trim(); //if not exists in database, use the tim in config file.
            }
            //if current time is equivalent to the configured time
            if (_CurrentTime == _scheduledRunningTime.Trim())
                {
                // 0 - Holiday, Saturday and Sunday, Do not send; 
                // 1 - Not Holiday, Not month-end, Send file; 
                // 2 - Do not pick the file for processing
                string result = Dispatcher.GetServerDate(connString);
                DateTime dateOfServer;
                //---------------------------------------
                if (result.ToString() != string.Empty)
                    {
                    dateOfServer = Convert.ToDateTime(result.Trim());
                    }
                else
                    {
                    dateOfServer = Convert.ToDateTime("01-01-1900");
                    }
                if (dateOfServer == Convert.ToDateTime("01-01-1900"))
                    {
                    dateOfServer = DateTime.Today; // Getting the local date and time if date is not available in server
                    }
                //Get if holiday today
                string resultHoliday = Dispatcher.GetHolidayThisMonth(dateOfServer, connString);
               
                //---------------------------------------
                //check if yesterday is holiday
                string holidayYesterday = Dispatcher.GetHolidayThisMonth(dateOfServer.AddDays(-1), connString);
                //========================
                if (holidayYesterday != string.Empty)
                    { // if yesterday is holiday
                    //------------------------------------------
                        return; //stop processing 
                    }
               //---------------------------------------------
               if (ifFileExist() == 1) { 
                Dispatcher.mainProcess(_scheduledRunningTime.Trim(), dateOfServer);
                if (resultHoliday.ToString() == string.Empty)
                    {
                    AAFGLInterface.sendFileToSFTPServer.sendFileToSFTPServer.UploadFile(1); //UploadFile(1), 1 Send to ICBS, 2 Getfile from ICBS
                    }
                }
                //----------------------------------------
            }
        }
        //---------------------------------------
        public static int ifFileExist()
            {
            int i = 0;
            string[] filesToTransfer = Directory.GetFiles(_sourcefilename, "*.txt");
            if (filesToTransfer.Length == 0)
                {
                i = 0;
                sendFileToSFTPServer.sendFileToSFTPServer.logger("No AAF File in GLInterface folder to process");
                }
            else
                {
                i = 1;
                }

            return i;
            }
        }
}
