﻿using System;
using System.IO;
using System.Configuration;
using ASCII_EBCDIC_Converter;
using System.Text;




namespace ASCII_EBCIDIC_Converter
{
    internal class Program
    {
        //private string sLogFormat;
        //private string sErrorTime;
               
        private static void Main(string[] args)
        {
          //  Process();


        }

        //public  static void Process()
        //{
        //    #region banner
        //    Console.WriteLine("\n=====================================================================");
        //    Console.WriteLine("BDOLF/BDORI ASCII / EBCDIC Convertor Util");
        //    Console.WriteLine("=====================================================================\n");
        //    #endregion
           
        //    try
        //    {
        //        string inFile,  outFile, convertTo, codePage, errorLogPath,  logFileFolder, mainFolder,fileToICBS;
        //        bool cRLF;
        //        int bytesToSkipForCRLF;
        //        //Getting values in Application Configuration
        //        GetConfigValues(out inFile, out outFile, out convertTo, out cRLF, out bytesToSkipForCRLF, out codePage, out errorLogPath, out logFileFolder,out mainFolder, out fileToICBS);


        //        //Checking and preparaing directories/folder to use
        //        if (!Directory.Exists(mainFolder))
        //        {
        //            System.IO.Directory.CreateDirectory(outFile);               //C:\tmp\BDOLF_ICBS
        //            System.IO.Directory.CreateDirectory(logFileFolder);         //C:\tmp\LogFiles
        //            System.IO.Directory.CreateDirectory(errorLogPath);          //C:\tmp\LogFiles\ErrorLog
        //            Environment.Exit(-1);
        //        }
                
        //        ////Filter AAF report with "BDOLFS" in the filename
        //        Run(inFile, outFile + @"\ICBSBLF.txt");
        //        ////Format: Run (Location of Directory, Output File)

        //        //// Merge Mulitple Files if Detected -------
        //        Merge(outFile, outFile + @"\ICBSBLFP1");   //ICBSBLFP1 - P1, code for first process(Merging)

        //        //-----------------------------------------
        //        //Remove/Trim trailing CRLF per line of the merged AAF extracted report
        //        RemoveTrailingCRLF rtCRLF = new RemoveTrailingCRLF();
        //        rtCRLF.removeTrailingCRLF(outFile + @"\ICBSBLFP1", outFile + @"\ICBSBLFP2");//ICBSBLFP - P2, code for second process(Removing Trailing CRLF)

             
        //        ////Convert the trimmed file into EBCDIC
        //        //Convertor.Convert(inFile, convertTo, outFile, cRLF, bytesToSkipForCRLF, codePage, errorLogPath);
        //        if (cRLF)
        //        {
        //            Convertor.Convert(outFile + @"\ICBSBLFP2", convertTo, outFile + @"\ICBSBLFP2", cRLF, bytesToSkipForCRLF, codePage, errorLogPath);
        //        }
        //        else
        //        {
        //            byte[] fileArray = File.ReadAllBytes(outFile + @"\ICBSBLFP2"); //Source
        //            fileArray = ConvertAsciiToEbcdic(fileArray, "IBM037");
        //            using (var fileStream = new FileStream(outFile + @"\" + fileToICBS, FileMode.Create, FileAccess.Write)) //Destination
        //            {
        //                fileStream.Write(fileArray, 0, fileArray.Length);
        //                fileStream.Close();
        //            }
        //        }
        //        //-----------------------------------------
        //        //Cleaning Directory
   
        //        File.Delete(outFile + @"\ICBSBLFP1");                                       // -----------------------------------------
        //        File.Delete(outFile + @"\ICBSBLFP2");
        //        // Send via sftp to ICBS

                
        //        //-----------------------------------------
        //        //Console.WriteLine("\nOutput file written: " + outFile);
        //        //Console.WriteLine("\nAll Done. Bye now.");

        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("\nOops, something broke!");
        //        Console.WriteLine(ex.Message);
        //        Console.WriteLine("\n");
        //        Environment.Exit(-1);
        //    }
        //}
        //public static byte[] ConvertAsciiToEbcdic(byte[] asciiData, string codepage)
        //{
        //    Encoding ascii = Encoding.ASCII;
        //    Encoding ebcdic = Encoding.GetEncoding(codepage);
        //    return Encoding.Convert(ascii, ebcdic, asciiData);
        //}
        //private static void GetConfigValues(out string inFile, out string outFile, out string convertTo, out bool cRLF,
        //    out int bytesToSkipForCRLF, out string codePage, out string errorLogPath, out string logFileFolder,out string mainFolder, out string fileToICBS)
        //{
        //    convertTo = ConfigurationManager.AppSettings["convertto"];
        //    cRLF = bool.Parse(ConfigurationManager.AppSettings["crlf"]);
        //    bytesToSkipForCRLF = int.Parse(ConfigurationManager.AppSettings["skipbytesforcrlf"]);
        //    codePage = ConfigurationManager.AppSettings["codepage"];

        //    //Folders information
        //    inFile = ConfigurationManager.AppSettings["sourcefilename"];
        //    outFile = ConfigurationManager.AppSettings["outputfilename"];
        //    errorLogPath = ConfigurationManager.AppSettings["errorLogPath"];
        //    logFileFolder = ConfigurationManager.AppSettings["logFileFolder"];
        //    mainFolder = ConfigurationManager.AppSettings["mainFolder"]; //location where the file to be processed
        //    fileToICBS = ConfigurationManager.AppSettings["fileToICBS"];
        //}


        //static void Run(string SourceDir, string OutputFileName)
        //{
        //    try
        //    {
        //        string inFile,  outFile, convertTo, codePage, errorLogPath, logFileFolder, mainFolder, fileToICBS;
        //        bool cRLF;
        //        int bytesToSkipForCRLF;
        //        //Getting values in Application Configuration
        //        GetConfigValues(out inFile, out outFile, out convertTo, out cRLF, out bytesToSkipForCRLF, out codePage, out errorLogPath, out logFileFolder, out mainFolder, out fileToICBS);

        //        //string[] inputFiles = Directory.GetFiles(SourceDir, "*FS*.txt");
        //        string[] inputFiles = Directory.GetFiles(SourceDir, "*.txt");
        //        int bufSize = 1024 * 64;
        //        byte[] buf = new byte[bufSize];

        //        //using (FileStream outFile =
        //        //new FileStream(OutputFileName, FileMode.OpenOrCreate,
        //        //FileAccess.Write, FileShare.None, bufSize))
        //        //{
        //        foreach (string inputFile in inputFiles)
        //        {
        //            //  DateTime.Today.ToString("MM/dd/yy") = 062517
        //            // File should be formatted like AAF062417BDOLFS1209.txt
        //            // AAFmmddyyBDOLF#xxxx.txt
        //            // # = S - Summary
        //            // # = D - Details
        //            //look for needed file only and transfer to ProcessFolder
        //            FileInfo fi = new FileInfo(inputFile);
        //            var filename = System.IO.Path.GetFileName(inputFile);
        //           // fi.CopyTo(outFile + @"\" + filename, true); // Sending to GL Interface folder, existing file will be overwritten
        //            if (filename.Substring(14, 1) == "S")
        //            {
        //                fi.CopyTo(outFile + @"\" + filename, true); // Sending to BDOLFFiles folder for merging, convertion to EBCDIC, existing file will be overwritten
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        string inFile, outFile, convertTo, codePage, errorLogPath, logFileFolder, mainFolder, fileToICBS;
        //        bool cRLF;
        //        int bytesToSkipForCRLF;
        //        //Getting values in Application Configuration
        //        GetConfigValues(out inFile, out outFile, out convertTo, out cRLF, out bytesToSkipForCRLF, out codePage, out errorLogPath, out logFileFolder, out mainFolder, out fileToICBS);

        //        //MessageBox.Show(e.Message);
        //        CreateLogFiles Err = new CreateLogFiles();
        //        //Err.ErrorLog(Server.MapPath("Logs/ErrorLog"), ex.Message);
                
        //        Err.ErrorLog(errorLogPath, e.Message);
        //        //Err.ErrorLog(@"c:\tmp\LogFiles\ErrorLog", e.Message);
        //        //Msg.Visible = true;
        //        //Msg.Text = "Fatal error : " + ex.Message + ", please find a complete error at ErrorLog file";
        //    }
        //}

        ////--Method to concatenate multiple files into single file-------------------
        //public static void Merge(string SourceDir, string OutputFileName)
        //{
        //    string[] inputFiles = Directory.GetFiles(SourceDir, "*FS*.txt");

        //    int bufSize = 1024 * 64;

        //    byte[] buf = new byte[bufSize];

        //    using (FileStream outFile =
        //    new FileStream(OutputFileName, FileMode.OpenOrCreate,
        //    FileAccess.Write, FileShare.None, bufSize))
        //    {
        //        foreach (string inputFile in inputFiles)
        //        {
        //            using (FileStream inFile =
        //            new FileStream(inputFile, FileMode.Open, FileAccess.Read,
        //            FileShare.Read, bufSize))
        //            {
        //                int br = 0;
        //                while ((br = inFile.Read(buf, 0, buf.Length)) != 0)
        //                {
        //                    outFile.Write(buf, 0, br);
        //                }
        //            }
        //        }
        //    }
        //}
        ////----Method to detect the -----------------    


        ////-----------------------


        //public string CreateLog()
        //{
        //    //sLogFormat used to create log files format :
        //    // dd/mm/yyyy hh:mm:ss AM/PM ==> Log Message
        //    sLogFormat = DateTime.Now.ToShortDateString().ToString() + " " + DateTime.Now.ToLongTimeString().ToString() + " ==> ";

        //    //this variable used to create log filename format "
        //    //for example filename : ErrorLogYYYYMMDD
        //    string sYear = DateTime.Now.Year.ToString();
        //    string sMonth = DateTime.Now.Month.ToString();
        //    string sDay = DateTime.Now.Day.ToString();
        //    sErrorTime = sMonth + sDay + sYear;
        //    return sErrorTime;
        //}


        //public void ErrorLog(string sPathName, string sErrMsg)
        //{
        //    string xLog = CreateLog();
        //    StreamWriter sw = new StreamWriter(sPathName + sErrorTime, true);
        //    sw.WriteLine(xLog + sErrMsg);
        //    sw.Flush();
        //    sw.Close();
        //}
        ////-----------------------



        //------------------------------
    }
}